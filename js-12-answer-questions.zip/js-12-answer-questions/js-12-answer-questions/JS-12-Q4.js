//? Question-4:Explain these things in the new EcmaScript standard with examples. (Explain in the form of an example.)
// todo:Using const, let instead of var
// todo:arrow function
// todo:template string instead of "" and ''
// todo:destructuring

//1- Using const, let instead of var

// We use const and let instead of var because vaar doesn't work properly everywhere. For example, var doesn't work properly in block scopes.

// if(true){
//     var test1=1
//     const test2=2
//     let test3=3
// }

// console.log(test1);   // 1
// console.log(test2);   // not defind
// console.log(test3);   // not defind

// // 2-arrow function

// An arrow function is a short form of a function that does not require a return if written on one line.

//  const arrow=(a,b)=>(a*b)
// console.log(arrow(2,3));

// 3-template string instead of "" and ''
// Strings and variables together
// const name="Diba"
// const favorite="read Books"
// const temp=`my name is ${name} and My favorite thing to do is ${favorite}`

// console.log(temp);

// 4-destructuring
// Getting a quantity
// const des = {
//   name: diba,
//   age: 18,
// };

// const { name } = des;

// console.log(name);
