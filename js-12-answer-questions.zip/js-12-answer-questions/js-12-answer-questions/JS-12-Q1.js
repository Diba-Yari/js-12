//! OPTIONAL
// ? Question-1:Using lexical scope, Write a function that displays the following outputs in order:
/**
 * Action
 * Potential
 * Signals
 */
// !Answer:

function displayAction() {
  console.log("Action");

  function displayPotential() {
    console.log("Potential");

    function displaySignals() {
     console.log("Signals");
    }
    displaySignals();
  }
  displayPotential();
}

displayAction();



